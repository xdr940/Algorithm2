
matlab
![here](https://github.com/xdr940/Algorithm2/blob/master/DBSCAN2/matlab_call/result.jpg)
![here](https://github.com/xdr940/Algorithm2/blob/master/DBSCAN2/matlab_call/result2.jpg)

python
![here](https://github.com/xdr940/Algorithm2/blob/master/DBSCAN2/python_call/result.jpg)
